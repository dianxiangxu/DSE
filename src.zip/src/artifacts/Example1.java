package artifacts;

import java.util.ArrayList;

public class Example1 {

	/*
	 * New example to really see how making new expressions work
	 * @author Hannah Johnson
	 */


    static int example_1(int x1, int y1) {
        x1 = x1 * 2;
        while (x1 != 2) {
            y1 = y1 + 2;
            while (y1 > 0) {
                y1--;
            }
            if (x1 == 0) {
                System.out.println("assert");
                System.exit(2);
            }
            x1++;
        }
        return y1;

    }

    /*
	 * In general if SA analyzes a particular part of CFG
	 * and finds that assertion violates, it will not be
	 * able to tell if violating path is feasible or not.
	 * Need to do SE to dismiss false positives.
	 * However, if SA tells that a particular part of CFG
	 * assertion does not violates then feasibility should 
	 * not be an issue. 
	 * Non proven fix right now is to find the 
	 * state change and make sure that different values are opposites, i.e., 0 and !0
     */
    static int example_2(int x1, int x2) {
        int x = x1 + x2;
        boolean cond_1;
        if (x == 0) {
            cond_1 = false;
        } else {
            cond_1 = true;
        }
        //cond_1 = x1==x2 && x != 5 && cond_1;
        boolean cond_2 = false;
        if (x1 == x2) {
            if (x != 5) {
                if (cond_1) {
                    cond_2 = true;
                }
            }
        }

        //if(x1==x2 && x != 5 && cond_1){
        if (cond_2) {
            System.out.println("assert");
            System.exit(2);
        }
        return x;
    }

    static int example_3(int x, int y) {
        if (x == 0) {
            y = 0;
        } else {
            y = 0;
        }

        if (y > 0) {
            x = y;
        } else {
            x = y + 1;
        }

        if (x >= 0) {
            System.out.println("assert");
        }
        return x;
    }

    static int example_4(int x, int y) {

        if (x != 0) {
            x = x + 0;
            while (y > 0) {
                x = x + 2;
                y = y - 1;
            }
        } else {
            x = x - 2;
        }

        if (x != 0) {
            System.out.println("assert");
        }
        return x;
    }

    /*
	 * This example shows that SA will determine that the 
	 * 3rd branch false outcome is infeasible, i.e., assertion violates.
	 * Yet, the path itself is infeasible. 
     */
    public int example_5(int x, int y) {
        x = x * 0;
        if (x > y) {
            if (x == y) {
                if (x == 0) {
                    System.out.println("assert");
                }
            }
        }
        return x + y;
    }

    public double example_6(double x, double ret) {
        double y = 0.0 * x;
        double ter = ret / 5.0;
        int z = (int) y;
        if (x > ret && y != z) {
            ret = 2 * ter + z;
        }
        return ret;
    }

    public double example_7(double x, double y) {
        double ret = -1.00;
        if (x == 0) {
            ret = x * 2;
        } else if (y >= ret) {
            ret = y;
        }

        if (ret == 0) {
            System.out.println("assertion violated");
        }
        return ret;
    }

    public int example_8(double x, byte y) {
        byte ret = (byte) 0;
        if (x <= 0) {
            ret = (byte) (y + ((byte) x));
        } else {
            x = ret;
        }

        if (x == 0) {
            System.out.println("assertion violated");
        }
        return (int) x;
    }
    
        static int example_9(int x, int y) {
        if (x > 0 || y > 0) {
            y = x + y;
        } else {
            y = y + 2;
        }

        if (y > 0) {
            x = y;
        } else {
            x = y + 1;
        }

        if (x >= 0) {
            System.out.println("assert");
        }
        return x;
    }
           
    static int example_10(int x1, int y1) {

        if (x1 > y1) {
            y1 = y1 + 2;
        } else {
            x1 = x1 + 3;
        }
        int z = x1 + y1;
        return z;
    }



    static int example_11(int x1, int y1) {
        int a = x1 * 5;

        if (a != 11) {
            x1 = y1 * 2;
        }

        if (x1 == 6) {
            while (x1 != 2) {
                y1 = y1 + 2;
                while (y1 > 0) {
                    y1--;
                }
                if (x1 >= 0) {
                    System.out.println("assert");
                }
                x1 = 0;
            }
        } else {
            y1 = 5;
        }
        x1++;
        y1 = -y1;
        return y1;

    }
    static int example_12(int x1, int y1) {
        int a = x1 + 5;
        int b = a - y1;

        if (b > a || b == a) {
            a = a * 5;
        } else {
            b = b * 5;
        }
        x1 = a * b;
        y1 = a / b;

        return x1;
    }

    static int example_13(int x1, int y1) {

        if (x1 > 5) 
        {
            if(x1>10)
            { 
                y1 = y1 + 2;
            }
            else
            {
                y1 = y1+ 4;
            }
        } 
        else {
            x1 = x1 + 3;
        }
        int z = x1 + y1;
        return z;
    }
	public static void main(String[] args){
		int x = Integer.valueOf(args[0]);
		int y = Integer.valueOf(args[1]);
		System.out.println(example_13(x,y));
	}

}

